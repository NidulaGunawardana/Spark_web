<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content>
    <meta name="author" content>

    <title>Project - Virtual Cycling</title>
    <link rel="icon" href="../images/tit.png" />
    <!-- CSS FILES -->
    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;300;400;700;900&display=swap" rel="stylesheet">

    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/bootstrap-icons.css" rel="stylesheet">

    <link rel="stylesheet" href="../css/slick.css" />

    <link href="../css/tooplate-little-fashion.css" rel="stylesheet">
    <link href="../css/hederCoustom.css" rel="stylesheet">


</head>

<body>

    <main>

        <nav class="navbar sticky-top navbar-expand-lg start-header start-style">
            <div class="container sticky-top mt-3 mb-3">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <a class="navbar-brand" href="index.html">
                    <a href="index.php"><img src="../images/Spark light.png" alt="Spark logo" style="height: 50px;"></a>
                </a>

                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav mx-auto">
                        <li class="nav-item">
                            <a class="nav-link text-light" href="../index.php">Home</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link text-light" href="../raspberryPi.php">Raspberry Pi Community</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link text-light" href="../communityFb.php">Community Facebook
                                Page</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link text-light" href="../softSkills.php">Soft Skills</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="../projects.php">Projects</a>
                        </li>
                    </ul>

                </div>
            </div>
        </nav>

        <header class="site-header section-padding-img site-header-image mt-0 tile-color pb-2">
            <div class="container">
                <div class="row">

                    <div class="col-12 text-center">
                        <div class="row h-100">
                            <h2 class="my-auto">
                                <span class="d-block text-light">Revolutionizing Indoor Cycling - A 5G-Powered Virtual Cycling Platform</span>
                            </h2>
                        </div>
                    </div>


                </div>
                <div class="row">
                    <div class="col-12 h-100">
                        <div class="px-5 pt-lg-3 text-center my-auto">
                            <p class="lead mt-3 fs-4 text-secondary">In the dynamic convergence of fitness and technology, a groundbreaking project is
                                reshaping the world of indoor cycling. This initiative is centered on the development of a
                                cutting-edge virtual cycling platform that harnesses the power of 5G technology, offering
                                cyclists a competitive and immersive experience irrespective of their geographical locations.</p>
                        </div>
                    </div>
                </div>


        </header>



        <section class="testimonial section-padding pt-2">
            <div class="container">
                <div class="row">

                    <div class="col-12 col-lg-10 offset-lg-1">
                        <h4 class="text-white">Key Technological Components</h4>
                        <p class="lead mb-3 text-secondary my-auto text-justify">The project's core foundation lies in the implementation of a robust 5G network through
                            Software Defined Radio (SDR). This strategic choice tackles latency and high bandwidth
                            issues, ensuring a seamless virtual environment. Complementing this, the integration of
                            Virtual Reality (VR) elevates the cycling experience. Cyclists equipped with Oculus devices
                            navigate a virtual world created by the Unity Gaming Engine, providing an engaging and
                            realistic encounter.
                        </p>

                    </div>
                </div>
                <div class="row">

                    <div class="col-12 col-lg-10 offset-lg-1">
                        <h4 class="text-white">Fostering Competition Across Distances</h4>
                        <p class="lead mb-3 text-secondary my-auto text-justify">Beyond mere virtuality, the platform introduces a competitive edge to indoor cycling. Cyclists
                            situated in different locations can engage in head-to-head virtual races, thanks to intricate
                            algorithms calculating relative positions. Avatars, generated based on gyroscope outputs,
                            simulate a sense of real-world competition, adding an exciting dimension to indoor cycling.</p>

                    </div>
                </div>



                <div class="row">

                    <div class="col-12 col-lg-10 offset-lg-1">
                        <h4 class="text-white">Addressing Safety and Comfort Concerns</h4>
                        <p class="lead mb-3 text-secondary my-auto text-justify">The motivation driving this project stems from the challenges associated with outdoor
                            cycling, including safety concerns amid heavy traffic. By encouraging cyclists to embrace
                            virtual platforms, the initiative aims to provide a safer and more comfortable alternative to
                            traditional cycling, especially relevant in regions where outdoor conditions pose risks.
                        </p>

                    </div>
                </div>

                <div class="row">

                    <div class="col-12 col-lg-10 offset-lg-1">
                        <h4 class="text-white">Innovative Integration of 5G Technology</h4>
                        <p class="lead mb-3 text-secondary my-auto text-justify">Setting this project apart is its pioneering use of 5G for all communications, marking a
                            significant advancement in the field. Unlike existing virtual cycling platforms, which often rely
                            on local servers with WiFi, this initiative leverages the capabilities of a standalone 5G
                            network implemented through OpenAijrinterface (OAI) and Software-Defined Radios (SDR).
                        </p>

                    </div>
                </div>
                <div class="row">

                    <div class="col-12 col-lg-10 offset-lg-1">
                        <h4 class="text-white">Applications and Potential Impacts</h4>
                        <p class="lead mb-3 text-secondary my-auto text-justify">The applications of this 5G-powered virtual cycling platform extend beyond individual fitness
                            enthusiasts. Targeting 360 video providers, game centers, fitness facilities, and cycling
                            enthusiasts, it also serves as a potential tool for promoting tourism through virtual tours. The
                            impact is not confined to specific regions; it globally influences research in virtual competitive
                            cycling, with plans to publish achievements in reputable journals.</p>

                    </div>
                </div>

                <div class="row">

                    <div class="col-12 col-lg-10 offset-lg-1">
                        <h4 class="text-white">Conclusion</h4>
                        <p class="lead mb-3 text-secondary my-auto text-justify">In conclusion, this project emerges as a visionary force reshaping indoor cycling. By
                            seamlessly integrating real-world video, competitive dynamics, and cutting-edge 5G
                            technology, it addresses safety concerns linked to outdoor cycling, creating a paradigm shift
                            in the realm of virtual cycling platforms.
                        </p>

                    </div>
                </div>


            </div>
        </section>

    </main>

    <footer class="site-footer">
        <div class="container">
            <div class="row">

                <div class="col-lg-3 col-10 me-auto mb-4">
                    <h4 class="text-white mb-3"><a href="index.html">SPARK</a> Challenge</h4>
                    <p class="copyright-text text-muted mt-lg-5 mb-4 mb-lg-0">Copyright © 2023 <strong>ENTC</strong></p>
                    <br>
                    <p class="copyright-text">Designed by <a href="https://www.linkedin.com/in/nidula-gunawardana-22819a1b3/" target="_blank">Nidula Gunawardana</a></p>
                </div>

                <div class="col-lg-5 col-8">
                    <h5 class="text-white mb-3">Sitemap</h5>

                    <ul class="footer-menu d-flex flex-wrap">
                        <li class="footer-menu-item"><a href="../index.php" class="footer-menu-link">Home</a></li>

                        <li class="footer-menu-item"><a href="../raspberryPi.php" class="footer-menu-link">Raspberry Pi Community</a></li>

                        <li class="footer-menu-item"><a href="../communityFb.php" class="footer-menu-link">Community Facebook Page</a></li>

                        <li class="footer-menu-item"><a href="../softSkills.php" class="footer-menu-link">Soft Skills</a></li>

                        <li class="footer-menu-item"><a href="../projects.php" class="footer-menu-link">Projects</a></li>
                    </ul>
                </div>

                <div class="col-lg-3 col-4">
                    <h5 class="text-white mb-3">Social</h5>

                    <ul class="social-icon">

                        <li><a href="#" class="social-icon-link bi-youtube"></a></li>

                        <li><a href="#" class="social-icon-link bi-whatsapp"></a></li>

                        <li><a href="#" class="social-icon-link bi-instagram"></a></li>

                        <li><a href="#" class="social-icon-link bi-skype"></a></li>
                    </ul>
                </div>

            </div>
        </div>
    </footer>


    <!-- JAVASCRIPT FILES -->
    <script src="../js/jquery.min.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <script src="../js/Headroom.js"></script>
    <script src="../js/jQuery.headroom.js"></script>
    <script src="../js/slick.min.js"></script>
    <script src="../js/custom.js"></script>

</body>

</html>